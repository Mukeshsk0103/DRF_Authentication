from django.contrib import admin
from .models import Users, BlackListedToken


@admin.register(Users)
class UsersAdmin(admin.ModelAdmin):
    list_display = ['id', 'email', 'city', 'state', 'password']

@admin.register(BlackListedToken)
class BlackListedTokenAdmin(admin.ModelAdmin):
    list_display = ['id', 'token', 'user']