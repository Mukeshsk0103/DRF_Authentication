from django.db import models
from django.contrib.auth.models import AbstractUser
from .manager import UserManager

class Users(AbstractUser):
    # Your custom fields here
    username = None
    email = models.EmailField(unique=True)
    contact_number = models.CharField(max_length=20)
    apartment = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    pin = models.CharField(max_length=6)
    created_by = models.ForeignKey('Users', on_delete=models.CASCADE,
                                   related_name='user_created', null=True,
                                   blank=True)
    updated_by = models.ForeignKey('Users', on_delete=models.CASCADE,
                                   related_name='user_updated', null=True,
                                   blank=True)
    created_at = models.DateTimeField(auto_now_add=True,null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True,null=True, blank=True)

    objects = UserManager()
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []

    def __str__(self):
        return f"{self.email}"
    
    class Meta:
        verbose_name_plural = 'User'


class BlackListedToken(models.Model):
    token = models.CharField(max_length=500)
    user = models.ForeignKey(Users, related_name="token_user", on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("token", "user")

