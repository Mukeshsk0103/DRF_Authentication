from rest_framework import serializers
from .models import Users
from django.contrib.auth import authenticate
from django.contrib.auth.password_validation import validate_password
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer


class UserRegistrationSerializers(serializers.ModelSerializer):
    confirm_password = serializers.CharField(write_only=True)

    def validate(self, data):
        if data.get('password') != data.get('confirm_password'):
            raise serializers.ValidationError("The passwords do not match.")
        return data

    def create(self, validated_data):
        validated_data.pop('confirm_password')  # Remove 'confirm_password' from validated_data
        password = validated_data.get('password')

        try:
            validate_password(password)  # Validate the password
        except Exception as e:
            raise serializers.ValidationError(str(e))

        user = Users.objects.create_user(**validated_data)
        return user

    class Meta:
        model = Users
        fields = ('email', 'password', 'confirm_password')
        

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        # fields = '__all__'
        fields = ('id', 'first_name', 'last_name', 'email', 'contact_number', 'apartment', 'city', 'state', 'country', 'pin', 'is_staff', 'last_login', 'date_joined',
                  'created_at', 'created_by', 'updated_at', 'updated_by')
        # exclude = ('groups', 'user_permissions', 'is_superuser', 'is_active')


class UserUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = ('id', 'first_name', 'last_name', 'contact_number', 'apartment', 'city', 'state', 'country', 'pin', 'is_staff', 'last_login',
                  'created_at', 'created_by', 'updated_at', 'updated_by')


class UserLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField()

    def validate(self, attrs):
        email = attrs.get('email')
        password = attrs.get('password')

        if email and password:
            user = authenticate(request=self.context.get('request'), email=email, password=password)
            if not user:
                msg = 'Unable to log in with provided credentials.'
                raise serializers.ValidationError(msg, code='authorization')
        else:
            msg = 'Must include "email" and "password".'
            raise serializers.ValidationError(msg, code='authorization')

        attrs['user'] = user
        return attrs

    def create(self, validated_data):
        # Since this serializer is used for login and not for creating new objects,
        # you don't need to implement the create method.
        # Just return the validated data as is.
        return validated_data


class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        data = super().validate(attrs)
        # Add custom validation or data manipulation here if needed
        return data