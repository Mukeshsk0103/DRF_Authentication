from django.urls import path
from django.contrib.auth import views as auth_views
from rest_framework_simplejwt.views import TokenRefreshView
from rest_framework_simplejwt.views import TokenVerifyView
from .views import UserRegistrationView,UsersListCreateAPIView, UsersRetrieveUpdateDestroyAPIView, home, LoggedInUserProfile, CustomTokenObtainPairView, LogoutView#, LoginAPI

urlpatterns = [
    # path('login/', LoginAPI.as_view(), name='login'),
    path('signup/', UserRegistrationView.as_view(), name='user_create'),
    path('login/', CustomTokenObtainPairView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
    path('user_profile/', LoggedInUserProfile.as_view(), name='user_profile'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('users/', UsersListCreateAPIView.as_view(), name='users_data'),
    path('verify/', TokenVerifyView.as_view(), name='token_verify'),
    path('users/<int:pk>', UsersRetrieveUpdateDestroyAPIView.as_view(), name='users_details_view'),
    path('home/', home, name='home'),
]
