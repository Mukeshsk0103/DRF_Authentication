# from rest_framework import generics, permissions
# from rest_framework.response import Response
# from rest_framework.views import APIView
# from rest_framework.authtoken.models import Token
# from django.contrib.auth import authenticate
# from .serializers import UserSerializer


# class UserRegistrationView(generics.CreateAPIView):
#     serializer_class = UserSerializer
#     permission_classes = [permissions.AllowAny]
from django.core.mail import EmailMultiAlternatives
from django.contrib.auth.tokens import default_token_generator
from django.http import JsonResponse
from django.shortcuts import render
from django.urls import reverse
from django.utils.encoding import force_bytes
from base64 import urlsafe_b64encode
from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth import authenticate, login
from .serializers import UserUpdateSerializer, UserRegistrationSerializers, UserSerializer, MyTokenObtainPairSerializer, UserLoginSerializer
from drf_yasg.utils import swagger_auto_schema
from django.core.mail import send_mail
from .models import Users, BlackListedToken
from DRF_token_authentication.settings import EMAIL_HOST_USER
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.authentication import TokenAuthentication
from rest_framework.authtoken.models import Token
from rest_framework_simplejwt.tokens import RefreshToken
# from rest_framework.permissions import IsAuthenticated, BasePermission
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.tokens import OutstandingToken, BlacklistedToken
from rest_framework.decorators import api_view, permission_classes
from django.contrib.auth import logout
from rest_framework.decorators import authentication_classes
import requests
from django.utils.http import urlsafe_base64_encode
from django.contrib.auth.tokens import default_token_generator
from django.template.loader import render_to_string
from DRF_token_authentication import settings
from django.template.loader import get_template
from django.contrib.auth.mixins import LoginRequiredMixin
from django.http import HttpResponseRedirect
from django.views import View



class IsTokenValid(permissions.BasePermission):
    def has_permission(self, request, view):
        user_id = request.user.id
        token = request.auth
        try:
            is_blacklisted = BlackListedToken.objects.get(user=user_id, token=token)
            if is_blacklisted:
                return False
        except BlackListedToken.DoesNotExist:
            return True
        return True


class CustomTokenObtainPairView(TokenObtainPairView):
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        if response.status_code == 200:
            refresh_token = response.data['refresh']
            access_token = response.data['access']
            request.session['refresh_token'] = refresh_token
            request.session['access_token'] = access_token
        return response


class LoggedInUserProfile(APIView):    
    # def get_(self, request, *args, **kwargs):
    def get(self, request, *args, **kwargs):
        print(request.user)
        user = Users.objects.get(id=request.user.id)
        serialize_data = UserSerializer(user)
        return Response(serialize_data.data)
    

class LogoutView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, format=None):
        
        token = request.auth
        BlackListedToken.objects.create(token=token, user=request.user)
        request.session.clear()

        return Response({"message": "Logged out successfully"}, status=status.HTTP_200_OK)
    
        
class UserRegistrationView(generics.CreateAPIView):
    serializer_class = UserRegistrationSerializers
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        return Users.objects.none()

    @swagger_auto_schema(request_body=UserRegistrationSerializers)
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        if response.status_code == status.HTTP_201_CREATED:
            data = response.data
            user = Users.objects.get(email=data.get('email'))
            self.send_activation_email(user)
            success_message = "User successfully created. Activation email sent."
            return Response({"detail": success_message}, status=status.HTTP_201_CREATED)
        return response

    def send_activation_email(self, user):
        subject = 'Activate your account'
        message = f"Hi {user},\n\nPlease click the following link to activate your account:\n\nhttp://example.com/activate/{urlsafe_b64encode(force_bytes(user.id))}/{default_token_generator.make_token(user)}"
        send_mail(subject, message, EMAIL_HOST_USER, [user])
        
        # message = render_to_string('email_template.html', {
        #     'user': user,
        #     'uid': urlsafe_base64_encode(force_bytes(user.id)),
        #     'token': default_token_generator.make_token(user),
        # })

        # send_mail(subject, message, EMAIL_HOST_USER, [user.email])
    # def send_activation_email(self, request, user):
    #     breakpoint()
    #     subject = 'Activate your account'
        # token = default_token_generator.make_token(user)
        # uid = urlsafe_base64_encode(force_bytes(user.id))
        # reset_url = reverse('password_reset_confirm',
        #                     kwargs={'uidb64': uid, 'token': token})
        # reset_url = f"http://{request.get_host()}{reset_url}"
        # from_email = settings.EMAIL_HOST_USER
        # recipient_list = [user.email]
        # message = EmailMultiAlternatives(subject=subject,
        #                                  from_email=from_email,
        #                                  to=recipient_list)
        # context = {'user': user, 'reset_url': reset_url}
        # html_template = get_template("email_template.html").render(context)
        # message.attach_alternative(html_template, "text/html")
        # message.send()
        


class UsersListCreateAPIView(ListCreateAPIView):
    serializer_class = UserSerializer
    queryset = Users.objects.all()
    permission_classes = [permissions.IsAuthenticated, IsTokenValid]


class UsersRetrieveUpdateDestroyAPIView(RetrieveUpdateDestroyAPIView):
    serializer_class = UserUpdateSerializer
    queryset = Users.objects.all()
    permission_classes = [permissions.IsAuthenticated, IsTokenValid]


@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def home(request):
    # headers = {
    #     'Authorization': "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzA5ODI2NjE3LCJpYXQiOjE3MDk4MTc3MzUsImp0aSI6IjI3MTkyYWViMGU2ZTRjZjM5N2UwNDNlMzhkMGYyM2Q2IiwidXNlcl9pZCI6MX0.XEgvtsUE-1B36f__pu-q1dUzryaknweqOZhyhmKzJr0"  # Include the authentication token here}
    # # }
    # breakpoint()
    # response = requests.get('http://127.0.0.1:8000/accounts/users/', headers=headers)
    # print(response)
    return render(request, 'home.html', context={'data': "Welcome"})
