import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'DRF_token_authentication.settings')

import django
import sqlite3
django.setup()

from Shopping_app.models import *
#
# sqliteConnection = sqlite3.connect('db.sqlite3')
# cursor = sqliteConnection.cursor()

# from Accounts.models import FileData
from faker import Faker
import random

fake = Faker('en_IN')

print(fake.__dict__)


def generate_shopping_items():
    categories = ["Food", "Electronic", "Vehicle", "Cloths", "Home Accessories"]
    part_name = random.choice(categories)
    trademark_symbol = random.choice(trademark_symbols)
    type = random.choice(part_types)
    return part_name + trademark_symbol, type


def fun(n):
    while range(n):
        category = random.choice(categories)
        name = generate_shopping_items()[0]
        value = fake.random_int(min=300, max=9999)
        type = generate_shopping_items()[1]
        if (3 <= len(str(value)) <= 4) and (value % 10) == 0:
            # print(name, type)
            # FileData.objects.update_or_create(name=name, defaults={'value': value})
            Item.objects.update_or_create(category=category, value=value,
                                              type=type)
        else:
            continue
        n -= 1


fun(50)
