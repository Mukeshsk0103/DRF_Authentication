 
from django.db.models import fields
from rest_framework import serializers
from .models import Item
 
class ItemSerializer(serializers.ModelSerializer):

    def create(self, validated_data):
        item = Item.objects.create(**validated_data)
        return item
    
    class Meta:
        model = Item
        fields = ('id', 'category', 'subcategory', 'name', 'amount')
        