# from django.shortcuts import get_object_or_404
# from rest_framework.decorators import api_view
# from rest_framework.response import Response
# from .models import Item
# from .serializers import ItemSerializer
# from rest_framework import serializers
# from rest_framework import status
# from drf_yasg.utils import swagger_auto_schema


# @api_view(['GET'])
# def ApiOverview(request):
#     api_urls = {
#         'all_items': '/',
#         'Search by Category': '/?category=category_name',
#         'Search by Subcategory': '/?subcategory=category_name',
#         'Add': '/create',
#         'Update': '/update/pk',
#         'Delete': '/item/pk/delete'
#     }
 
#     return Response(api_urls)


# @swagger_auto_schema(method='post', request_body=ItemSerializer)
# @api_view(['POST'])
# def add_items(request):
# 	item = ItemSerializer(data=request.data)

# 	# validating for already existing data
# 	if Item.objects.filter(**request.data).exists():
# 		raise serializers.ValidationError('This data already exists')

# 	if item.is_valid():
# 		item.save()
# 		return Response(item.data)
# 	else:
# 		return Response(status=status.HTTP_404_NOT_FOUND)


# @api_view(['GET'])
# def view_items(request, pk=None):  
#     # If a primary key is provided, fetch the specific item
#     if pk is not None:
#         try:
#             item = Item.objects.get(id=pk)
#             serializer = ItemSerializer(item)
#             return Response(serializer.data)
#         except Item.DoesNotExist:
#             return Response(status=status.HTTP_404_NOT_FOUND)
    
#     # If no primary key is provided, fetch all items
#     items = Item.objects.all()

#     if items:
#         serializer = ItemSerializer(items, many=True)
#         return Response(serializer.data)
#     else:
#         return Response(status=status.HTTP_404_NOT_FOUND)


# @swagger_auto_schema(method='post', request_body=ItemSerializer)
# @api_view(['POST'])
# def update_items(request, pk):
# 	item = Item.objects.get(pk=pk)
# 	data = ItemSerializer(instance=item, data=request.data)
    
# 	if data.is_valid():
# 		data.save()
# 		return Response(data.data)
# 	else:
# 		return Response(status=status.HTTP_404_NOT_FOUND)
	


# @api_view(['DELETE'])
# def delete_items(request, pk):
# 	item = get_object_or_404(Item, pk=pk)
# 	item.delete()
# 	return Response(status=status.HTTP_202_ACCEPTED)


from django.http import Http404
from rest_framework import generics
from rest_framework.response import Response
from rest_framework import status
from .models import Item
from .serializers import ItemSerializer
from drf_yasg.utils import swagger_auto_schema
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from DRF_token_authentication.settings import SECRET_KEY


class ItemListCreateAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        # breakpoint()
        print(request.user)
        queryset = Item.objects.all()
        serializer = ItemSerializer(queryset, many=True)
        return Response(serializer.data)
    
    @swagger_auto_schema(request_body=ItemSerializer)
    def post(self, request, *args, **kwargs):
        serializer = ItemSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ItemRetrieveUpdateDestroyAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return Item.objects.get(pk=pk)
        except Item.DoesNotExist:
            raise Http404

    def get(self, request, pk, *args, **kwargs):
        item = self.get_object(pk)
        serializer = ItemSerializer(item)
        return Response(serializer.data)

    @swagger_auto_schema(request_body=ItemSerializer)
    def put(self, request, pk, *args, **kwargs):
        item = self.get_object(pk)
        serializer = ItemSerializer(item, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @swagger_auto_schema(request_body=ItemSerializer)
    def patch(self, request, pk, *args, **kwargs):
        item = self.get_object(pk)
        serializer = ItemSerializer(item, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, *args, **kwargs):
        item = self.get_object(pk)
        item.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

